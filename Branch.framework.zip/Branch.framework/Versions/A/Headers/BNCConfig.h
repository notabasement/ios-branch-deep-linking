//
//  BNCConfig.h
//  Branch-SDK
//
//  Created by Qinwei Gong on 10/6/14.
//  Copyright (c) 2014 Branch Metrics. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString * const SDK_VERSION;
extern NSString * const BNC_API_BASE_URL;
extern NSString * const BNC_LINK_URL;
extern NSString * const BNC_API_VERSION;
